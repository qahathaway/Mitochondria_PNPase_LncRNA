# Mitochondrial Non-Coding RNA (ncRNA) Network
Code for sequencing parameters and machine learning algorithms specific for mitochondrial transcriptomic analyses
